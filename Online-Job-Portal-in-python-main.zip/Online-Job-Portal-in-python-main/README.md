# Online-Job-Portal-in-python
Online Job AThis Online Job Portal is an application where the job seekers can register themselves at the website and search for jobs that are suitable for them as the employers register with the website and put up jobs that are vacant at their company.
